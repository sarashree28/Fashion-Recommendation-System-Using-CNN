# Fashion_recommendention_system
A Fashion recommendation system using resnet-50
